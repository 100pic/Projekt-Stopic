<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="Slike/favicon.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="Ekipe.css" type="text/css">
    <title>NBA Ekipe</title>
</head>

<?php
$xml_teams = simplexml_load_file("Ekipe.xml");
?>

<body>
    <header>
        <div>
            <a href="index.html"><img src="Slike/NBA-logo-png.png" alt="NBA Logo"></a>
        </div>
        <div>
            <a href="index.html" class="nav-link">Početna </a>
            <a href="Ekipe.php" class="nav-link">Ekipe</a>
        </div>
    </header>

    <main>
        <div class="choice">
            <h1>Odaberi ekipu</h1>
            <form action="#" method="post">
                <select name="team">
                    <option disabled selected>Odaberi</option>
                    <?php foreach ($xml_teams->Ekipa as $team): ?>
                        <option value="<?php echo "$team->Naziv"; ?>"><?php echo "$team->Naziv" ?></option>
                    <?php endforeach; ?>
                </select>

                <button name="button" type="submit" class="btn btn-danger">Search</button>
            </form>
        </div>

        <?php
        if (!empty($_POST["team"])) {
            $NazivKipe = $_POST["team"];

            foreach ($xml_teams->Ekipa as $team) {
                if ($NazivKipe == $team->Naziv) {
                    $trener = $team->ImeTrenera;
                    $dvorana = $team->NazivDvorane;
                    $lokacija = $team->Lokacija;
                    $naslovi = $team->BrojOsvojenihNaslova;
                    $igraci = $team->NajpoznatijiIgraci;

                    break;
                }
            }

            echo "<div class='result'>";
            echo "<div class='name'>" . "Naziv: " . $NazivKipe . "</div>";
            echo "<div class='name'>" . "Trener: " . $trener . "</div>";
            echo "<div class='name'>" . "Arena Name: " . $dvorana . "</div>";
            echo "<div class='name'>" . "Lokacija: " . $lokacija . "</div>";
            echo "<div class='name'>" . "Naslovi: ", $naslovi . "</div>";
            echo "<div class='name'>" . "Najpoznatiji igrači: " . $igraci . "</div>";
            echo "</div>";
        }
        ?>
    </main>

    <footer>
        Antonio Stopić - 0246103499
    </footer>
